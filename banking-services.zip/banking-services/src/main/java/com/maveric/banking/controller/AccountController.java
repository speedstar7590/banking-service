package com.maveric.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maveric.banking.pojo.AccountDetails;
import com.maveric.banking.service.AccountService;

@RestController
@RequestMapping("/banking/")
public class AccountController {

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private AccountService service;

	@CrossOrigin
	@PostMapping("createAccount")
	public ResponseEntity<String> createAccount(@RequestBody AccountDetails details) throws JsonProcessingException {
		try {

			return new ResponseEntity<String>(mapper.writeValueAsString(service.createAccount(details)), HttpStatus.OK);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	@CrossOrigin
	@PostMapping("depositAmount")
	public ResponseEntity<String> depositAmount(@RequestBody AccountDetails details) throws JsonProcessingException {
		try {

			return new ResponseEntity<String>(mapper.writeValueAsString(service.depositAmount(details)), HttpStatus.OK);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	@CrossOrigin
	@PostMapping("withdrawAmount")
	public ResponseEntity<String> withdrawAmount(@RequestBody AccountDetails details) throws JsonProcessingException {
		try {

			return new ResponseEntity<String>(mapper.writeValueAsString(service.withdrawAmount(details)),
					HttpStatus.OK);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	@CrossOrigin
	@GetMapping("showBalance")
	public ResponseEntity<String> showBalance(@RequestParam String accNumber) throws JsonProcessingException {
		try {

			return new ResponseEntity<String>(mapper.writeValueAsString(service.showBalance(accNumber)), HttpStatus.OK);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

	@CrossOrigin
	@PostMapping("showTransactions")
	public ResponseEntity<String> showTransactions(@RequestBody AccountDetails acc) throws JsonProcessingException {
		try {

			return new ResponseEntity<String>(mapper.writeValueAsString(service.showTransactions(acc)), HttpStatus.OK);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}
}
