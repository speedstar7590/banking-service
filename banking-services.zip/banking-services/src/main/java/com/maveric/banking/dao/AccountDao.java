package com.maveric.banking.dao;

import com.maveric.banking.pojo.AccountDetails;

public interface AccountDao {

	public String createAccount(AccountDetails details);

	public String depositAmount(AccountDetails details);

	public String withdrawAmount(AccountDetails details);

	public void showBalance(String accNumber);

	public void showTransactions(AccountDetails acc);

}
