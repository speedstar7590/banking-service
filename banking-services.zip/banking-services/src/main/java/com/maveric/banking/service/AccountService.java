package com.maveric.banking.service;

import com.maveric.banking.pojo.AccountDetails;

public interface AccountService {

	public String createAccount(AccountDetails details);

	public String depositAmount(AccountDetails details);

	public String withdrawAmount(AccountDetails details);

	public String showBalance(String accNumber);

	public String showTransactions(AccountDetails acc);
}
