package com.maveric.banking.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.maveric.banking.dao.AccountDao;
import com.maveric.banking.pojo.AccountDetails;
import com.maveric.banking.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDao dao;

	@Override
	public String createAccount(AccountDetails details) {
		try {
			return dao.createAccount(details);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public String depositAmount(AccountDetails details) {
		try {
			return dao.depositAmount(details);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public String withdrawAmount(AccountDetails details) {
		try {
			return dao.withdrawAmount(details);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	@Override
	public String showBalance(String accNumber) {
		try {
			dao.showBalance(accNumber);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return "success";
	}

	@Override
	public String showTransactions(AccountDetails acc) {
		try {
			dao.showTransactions(acc);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		return "success";
	}

}
