package com.maveric.banking.utility;

public class Constants {

	public static final String DEPOSIT_SUCCESS = "Amount Credited Succesfully";
	public static final String DEPOSIT_FAILURE = "Account Number not matched";
	
	public static final String WITHDRAW_SUCCESS = "Amount Withdraw Succesfully";
	public static final String WITHDRAW_FAILURE = "In Sufficient Amount";
	
	public static final String SHOW_BALANCE_FAILURE = "No Account Number found";
	
	public static final String SHOW_TRANSACTIONS = "Transaction List";
	
}
