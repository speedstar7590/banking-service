package com.lotus.eott;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EottServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
